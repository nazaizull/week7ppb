import 'package:flutter/material.dart';
import 'package:flutter_application_1/catatan.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});

  @override
  State<MainApp> createState() => _MainAppState();
}

class _MainAppState extends State<MainApp> {
  TextEditingController judulCtr = TextEditingController();
  TextEditingController isiCtr = TextEditingController();
  List<Catatan> listCatatan = [];
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Catatan Pagi"),
          centerTitle: true,
        ),
        body: Container(
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Column(children: <Widget>[
            TextField(
              controller: judulCtr,
              decoration: InputDecoration(hintText: "Judul Catatan"),
            ),
            TextField(
              controller: isiCtr,
              decoration: InputDecoration(hintText: "Ini Catatan"),
            ),
            Row(
              children: [
                ElevatedButton(
                    onPressed: () {
                      judulCtr.clear();
                      isiCtr.clear();
                    },
                    child: Text("Clear")),
                ElevatedButton(
                    onPressed: () {
                      setState(() {
                        listCatatan.add(
                            Catatan(judul: judulCtr.text, ini: isiCtr.text));
                      });
                    },
                    child: Text("Submit")),
              ],
            ),
            Expanded(
                child: ListView.builder(
                    itemCount: 10,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text("Catatan $index"),
                        subtitle: Text("Isi catatan "),
                      );
                    }))
          ]),
        ),
      ),
    );
  }
}
